const express = require('express');
const { collectDefaultMetrics, register, Histogram } = require('prom-client');

const app = express();
const port = 3001;

// Сбор стандартных метрик
collectDefaultMetrics();

// Пример своей метрики
const httpRequestDurationMicroseconds = new Histogram({
    name: 'http_request_duration_seconds',
    help: 'Duration of HTTP requests in seconds',
    labelNames: ['method', 'route'],
});

app.get('/your-endpoint', (req, res) => {
    const end = httpRequestDurationMicroseconds.startTimer();
    // Ваш код для обработки запроса
    res.send('Hello World!');
    end({ method: req.method, route: req.path });
});

app.get('/metrics', async (req, res) => {
    res.set('Content-Type', register.contentType);
    res.end(await register.metrics());
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});