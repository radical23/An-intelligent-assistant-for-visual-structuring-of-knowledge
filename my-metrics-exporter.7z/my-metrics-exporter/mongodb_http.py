import requests
from pymongo import MongoClient

# Настройки
PROMETHEUS_URL = 'http://localhost:9090/api/v1/metrics'  # URL вашего сервера Prometheus
MONGO_URI = 'mongodb://localhost:27017/'  # URL вашего сервера MongoDB
DB_NAME = 'metrics_db'  # Имя базы данных
COLLECTION_NAME = 'metrics'  # Имя коллекции

def save_metrics_to_mongo(metrics):
    # Подключение к MongoDB
    mongo_client = MongoClient(MONGO_URI)
    db = mongo_client[DB_NAME]
    collection = db[COLLECTION_NAME]

    # Сохранение метрик
    for metric in metrics:
        # Создание документа для сохранения
        metric_data = {
            'metric_name': metric
        }
        collection.update_one(
            {'metric_name': metric},  # Условие для обновления
            {'$setOnInsert': metric_data},  # Сохранение только новых метрик
            upsert=True  # Вставка, если метрика не существует
        )
    print(f'Saved {len(metrics)} metrics to MongoDB.')

def get_all_metrics():
    # Получение всех метрик из Prometheus
    response = requests.get(PROMETHEUS_URL)
    if response.status_code == 200:
        print("Successfully fetched metrics from Prometheus.")
        return response.text.splitlines()  # Возвращает список метрик
    else:
        print(f"Failed to fetch metrics. Status code: {response.status_code}")
        return []

def main():
    metrics = get_all_metrics()
    if metrics:
        save_metrics_to_mongo(metrics)

if __name__ == '__main__':
    main()