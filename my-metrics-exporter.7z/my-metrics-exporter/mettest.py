import requests
from pymongo import MongoClient

# Настройки подключения к MongoDB
mongo_client = MongoClient('mongodb://localhost:27017/')
db = mongo_client['metrics_db']
collection = db['metrics']

# URL вашего Prometheus
prometheus_url = 'http://localhost:9090/api/v1'

# Получение всех метрик
def get_all_metric_names():
    try:
        # Используем регулярное выражение, чтобы получить все метрики
        response = requests.get(f"{prometheus_url}/series", params={'match[]': '{__name__=~".+"}'})
        response.raise_for_status()  # Проверка на ошибки HTTP
        data = response.json()

        # Проверяем структуру данных
        if 'data' in data:
            # Извлекаем имена метрик
            return list(set(metric['__name__'] for metric in data['data']))
        else:
            print("Response does not contain 'data':", data)
            return []

    except requests.exceptions.RequestException as e:
        print(f"Error fetching metric names: {e}")
        return []

# Запрос метрики по имени
def get_metric_data(metric_name):
    try:
        response = requests.get(f"{prometheus_url}/query", params={'query': metric_name})
        response.raise_for_status()  # Проверка на ошибки HTTP
        data = response.json()

        if 'data' in data:
            return data['data']['result']
        else:
            print(f"Response does not contain 'data' for metric '{metric_name}':", data)
            return []

    except requests.exceptions.RequestException as e:
        print(f"Error fetching metric data for '{metric_name}': {e}")
        return []

# Сохранение метрик в MongoDB
def save_metrics(metrics):
    for metric in metrics:
        # Сохраняем только уникальные метрики
        collection.update_one(
            {'_id': str(metric['metric'])},  # Уникальный идентификатор
            {'$set': metric},                # Обновление или вставка метрики
            upsert=True
        )

# Основной код
if __name__ == "__main__":
    metric_names = get_all_metric_names()
    total_saved_metrics = 0  # Счетчик сохраненных метрик

    if metric_names:
        for metric_name in metric_names:
            metrics = get_metric_data(metric_name)
            save_metrics(metrics)
            total_saved_metrics += len(metrics)  # Увеличиваем счетчик на количество сохраненных метрик

    print(f"Total saved metrics: {total_saved_metrics}")  # Выводим общее количество сохраненных метрик
