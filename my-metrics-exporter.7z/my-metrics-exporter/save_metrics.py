import requests
from pymongo import MongoClient

# Настройки подключения к MongoDB
mongo_client = MongoClient('mongodb://localhost:27017/')
db = mongo_client['metrics_db']
collection = db['metrics']

# URL вашего Prometheus
prometheus_url = 'http://localhost:9090/api/v1/query'

# Запрос метрик
def get_metrics(query):
    response = requests.get(prometheus_url, params={'query': query})
    data = response.json()
    return data['data']['result']

# Сохранение метрик в MongoDB
def save_metrics(metrics):
    for metric in metrics:
        # Сохраняем только уникальные метрики
        collection.update_one(
            {'_id': metric['metric']},  # Уникальный идентификатор
            {'$set': metric},           # Обновление или вставка метрики
            upsert=True
        )

# Основной код
if __name__ == "__main__":
    # Замените 'your_metric_name' на нужную метрику
    metrics = get_metrics('up')
    save_metrics(metrics)
    print(f"Saved {len(metrics)} metrics to MongoDB.")